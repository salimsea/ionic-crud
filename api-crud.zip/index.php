<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Credentials: true");
header("Access-Control-Allow-Methods: PUT, GET, POST, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Origin, Content-Type, Authorization, Accept, X-Requested-With, x-xsrf-token");
header("Content-Type: application/json");
include "config.php";
define("URL", "http://localhost/crud-api/");

function responseJson($msg, $data = null){
    $array = [
        "status" => !$msg ,
        "message" => $msg,
        "data" => $data
    ];
    
    return print_r(json_encode($array, JSON_PRETTY_PRINT));
}

function getAll() {
    $sql = "SELECT * FROM tb_mahasiswa";
    $query = dbQuery($sql);
    while($row = mysqli_fetch_array($query)){
        $dataUser[] = array(
            "kd"=> $row['id'],
            "npm"=> $row['npm'],
            "nama_mahasiswa"=> $row['nama'],
            "jenis_kelamin"=> $row['jenis_kelamin'],
            "jurusan"=> $row['jurusan'],
            "foto_siswa"=> URL."upload/".$row['foto'],
        );
    }
    if(dbNumRows($query) > 0) {
        return responseJson(null, $dataUser);
    } else {
        return responseJson("data tidak ada");
    }
}

function getId($id) {
    $sql = "SELECT * FROM tb_mahasiswa WHERE id = '$id'";
    $query = dbQuery($sql);
    $row = mysqli_fetch_array($query);
    $data = [
        "kd"=> $row['id'],
        "npm"=> $row['npm'],
        "nama_mahasiswa"=> $row['nama'],
        "jenis_kelamin"=> $row['jenis_kelamin'],
        "jurusan"=> $row['jurusan'],
        "foto_siswa"=> URL."upload/".$row['foto'],
    ];
    if($row != null) {
        return responseJson(null, $data);
    } else {
        return responseJson("data tidak ada");
    }
}

function insert($data){
    $npm = $data["npm"];
    $nama = $data["nama_mahasiswa"];
    $jk = $data["jenis_kelamin"];
    $jurusan = $data["jurusan"];
    $foto = $data["foto_siswa"];
    $namaFile = $foto['name'];

    $sql = "INSERT INTO tb_mahasiswa (npm, nama, jenis_kelamin, jurusan, foto)
    VALUES ($npm, '$nama', '$jk', '$jurusan', '$namaFile')";
    

    // upload file
    $namaSementara = $foto['tmp_name'];
    $dirUpload = "upload/";
    $terupload = move_uploaded_file($namaSementara, $dirUpload.$namaFile);
    if (!$terupload) {
        return responseJson("file foto wajib di upload!!");
    }

    if (dbQuery($sql)) {
        $id = dbInsertId();
        $data = [
            "id"=> $id,
            "npm"=> $npm,
            "nama"=> $nama,
            "jenis_kelamin"=> $jk,
            "jurusan"=> $jurusan,
            "foto"=> $namaFile,
        ];
        return responseJson(null, $data);
    } else {
        $msg = "Error: " . $sql ;
        return responseJson($msg);
    }
}

function update($data){
    $id = $data["id"];
    $npm = $data["npm"];
    $nama = $data["nama_mahasiswa"];
    $jk = $data["jenis_kelamin"];
    $jurusan = $data["jurusan"];
    $foto = $data["foto_siswa"];
    

    $sql = "SELECT * FROM tb_mahasiswa WHERE id = '$id'";
    $query = dbQuery($sql);
    $row = mysqli_fetch_array($query);
    if($row == null) {
        return responseJson("mahasiswa tidak ada");
    }

    if($foto != "" or $foto) {
        $namaFile = $foto['name'];
    } else {
        $namaFile = $row['foto'];
    }

    $sql = "UPDATE tb_mahasiswa SET npm=$npm, nama='$nama', jenis_kelamin='$jk', jurusan='$jurusan', foto='$namaFile' WHERE id=$id";

    // upload file
    $namaSementara = $foto['tmp_name'];
    $dirUpload = "upload/";
    $terupload = move_uploaded_file($namaSementara, $dirUpload.$namaFile);
    

    if (dbQuery($sql)) {
        $data = [
            "id"=> $id,
            "npm"=> $npm,
            "nama_mahasiswa"=> $nama,
            "jenis_kelamin"=> $jk,
            "jurusan"=> $jurusan,
            "foto"=> $namaFile,
        ];
        return responseJson(null, $data);
    } else {
        $msg = "Error: " . $sql ;
        return responseJson($msg);
    }
}

function delete($id){
    $sql = "SELECT * FROM tb_mahasiswa WHERE id = '$id'";
    $query = dbQuery($sql);
    $row = mysqli_fetch_array($query);
    if($row == null) {
        return responseJson("mahasiswa tidak ada");
    }

    $sql = "DELETE FROM tb_mahasiswa WHERE id = '$id'";
    $query = dbQuery($sql);
    if (dbQuery($sql)) {
        return responseJson(null, $id);
    } else {
        $msg = "Error: " . $sql ;
        return responseJson($msg);
    }
}

$getAction = @$_GET['action'];
$id = @$_GET["kd"];
$npm = @$_POST["npm"];
$nama = @$_POST["nama_mahasiswa"];
$jk = @$_POST["jenis_kelamin"];
$jurusan = @$_POST["jurusan"];
$foto = @$_FILES["foto_siswa"];
$data = [
        "id"=> $id,
        "npm"=> $npm,
        "nama_mahasiswa"=> $nama,
        "jenis_kelamin"=> $jk,
        "jurusan"=> $jurusan,
        "foto_siswa"=> $foto,
    ];

if ($getAction != null) {
    
    if($getAction == "getAll") 
        return getAll();
    if($getAction == "get") 
        return getId($id);
    if($getAction == "insert") 
        return insert($data);
    if($getAction == "update") 
        return update($data);
    if($getAction == "delete") 
        return delete($id);
    
   
} else {
    $data = [
        "status" => false,
        "msg" => 'yang bener ganteng'
    ];
    print_r(json_encode($data, JSON_PRETTY_PRINT));
}
?>

